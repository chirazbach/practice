package asd.model;

import org.junit.Before;
import org.junit.Test;
import javax.swing.*;
import java.util.Scanner;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;

public class DiscountTest {

    private Product Parfum;

    @Before
    public void setUp(){
        Parfum = new Product(1,"asd", "5", 1000 );


        double  dis,amount,markedprice,s;

        markedprice=1000;

        dis=25;  // 25 mean 25%


        System.out.println("markedprice= "+markedprice);

        System.out.println("discount rate="+dis);

        s=100-dis;

        amount= (s*markedprice)/100;

        System.out.println("amount after discount="+amount);


    }




    @Test
    public void testgetDiscountPercent() {

        Integer expected = 1;
        Integer actual =Parfum.getDiscountPercent();
        assertEquals(expected,actual);

}
}