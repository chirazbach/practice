package asd.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

    public class ShoppingCart {
        Map<Product, Integer> items;

        private List<Product> productList = new ArrayList<>();

        public ShoppingCart() {
            items = new HashMap<>();


        }


        public Map<Product, Integer> getItems() {
            return items;
        }

        public void addProduct(Product product){
            if(items.containsKey(product)){
                items.compute(product, (p,q ) -> Integer.valueOf(q+1));
            }else{
                items.put(product, 1);
            }
        }

        public void removeProduct(Product product){
            if(items.get(product).intValue() > 1){
                items.compute(product, (p, q) -> Integer.valueOf(q-1));
            }else{
                items.remove(product);
            }
        }

        public double getTotalCartValue() {
            double totalCartValue=0 ;

            if (productList.size() > 0) {

                for (Product product : productList) {
                    totalCartValue = totalCartValue + product.getProductPrice();
                }
            }
            return totalCartValue;
        }

        public int getProductCount() {

            return productList.size();
        }
    }